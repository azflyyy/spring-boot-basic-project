package com.ensakh.sitegestion.repository;

import com.ensakh.sitegestion.entity.Filliere;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FilliereRepository  extends JpaRepository<Filliere,Long> {
}
