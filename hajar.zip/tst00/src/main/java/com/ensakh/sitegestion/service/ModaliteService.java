package com.ensakh.sitegestion.service;

import com.ensakh.sitegestion.entity.Modalite;

import java.util.List;

public interface ModaliteService {
    List<Modalite> getAll();
}
