package com.ensakh.sitegestion.service;


import com.ensakh.sitegestion.entity.Module;

import java.util.List;

public interface ModuleService {
    List<Module> getAll();
}
