package com.ensakh.sitegestion.repository;


import com.ensakh.sitegestion.entity.Modalite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModaliteRepository extends JpaRepository<Modalite,Long> {
}
