package com.ensakh.sitegestion.service;

import com.ensakh.sitegestion.entity.Professeur;

import java.util.List;

public interface ProfesseurService {
    List<Professeur> getAll();

}
