package com.ensakh.sitegestion.repository;

import com.ensakh.sitegestion.entity.Professeur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesseurRepository extends JpaRepository<Professeur,Long> {
}
