package com.ensakh.sitegestion.service;


import com.ensakh.sitegestion.entity.Filliere;

import java.util.List;

public interface FilliereService {
    List<Filliere> getAll();
}