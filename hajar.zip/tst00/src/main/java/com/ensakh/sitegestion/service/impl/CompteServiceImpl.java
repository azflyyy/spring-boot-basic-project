package com.ensakh.sitegestion.service.impl;

import com.ensakh.sitegestion.entity.Compte;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class CompteMetierImpl implements CompteServiceImpl {
    @Autowired
    private Compte compteInt;

    public CompteMetierImpl(Compte compteInt) {
        this.compteInt = compteInt;
    }

    @Override
    public List<Compte> getAll() {
        return compteInt.findAll();
    }


    @Override
    public Compte save(Compte compte) {
        Compte compte1 = new Compte(compte.getEmail(),new BCryptPasswordEncoder().encode(compte.getMdp()));
        return compteInt.save(compte1);
    }
}