package com.ensakh.sitegestion.service;

import com.ensakh.sitegestion.entity.Compte;;

import java.util.List;


import java.util.List;

public interface CompteService {
    Compte save(Compte compte);
    List<Compte> getAll();

}