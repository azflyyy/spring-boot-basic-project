package com.ensakh.sitegestion.service;

import com.ensakh.sitegestion.entity.Element;

import java.util.List;

public interface ElementService {
    List<Element> getAll();
}
